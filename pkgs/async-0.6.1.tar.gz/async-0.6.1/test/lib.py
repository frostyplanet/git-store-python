"""Module with shared tools for testing"""
import unittest


class TestBase(unittest.TestCase):
	"""Common base for all tests"""
