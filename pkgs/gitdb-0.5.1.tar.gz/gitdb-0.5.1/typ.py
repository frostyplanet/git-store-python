"""Module containing information about types known to the database"""

#{ String types 

str_blob_type = "blob"
str_commit_type = "commit"
str_tree_type = "tree"
str_tag_type = "tag"

#} END string types
